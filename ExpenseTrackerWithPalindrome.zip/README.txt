Expense Tracker with Palindrome Checker (Console-Based Java App)
---------------------------------------------------------
Features:
- Add, Edit, Delete, View Expenses
- Palindrome Checker (Menu Option)
- SQLite Integration
- Export to JSON, XML, Excel (Apache POI)
- Console-based interface
- Runnable JAR included

How to Run:
1. Ensure Java is installed.
2. Open terminal and run:
   java -jar ExpenseTrackerWithPalindrome.jar
