
# Expense Tracker Application

## Features
- Account creation, deposits, withdrawals
- Categorized expenses and transaction history
- JSON/XML/Excel import and export
- Java Swing GUI
- SQLite database support

## How to Run
Make sure Java 17+ is installed.

```bash
java -jar ExpenseTrackerApp.jar
```
